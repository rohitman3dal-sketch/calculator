// Initialize calculator on page load
document.addEventListener('DOMContentLoaded', function() {
    // Hide all calculators initially
    document.querySelectorAll('.calculator-box').forEach(box => {
        box.style.display = 'none';
    });
    
    // Show welcome message
    console.log('Calculator Hub Initialized!');
});

// Show selected calculator
function showCalculator() {
    // Hide all calculators
    document.querySelectorAll('.calculator-box').forEach(box => {
        box.style.display = 'none';
    });
    
    // Get selected type
    let type = document.getElementById("calculatorType").value;
    
    // Show selected calculator
    if (type) {
        document.getElementById(type).style.display = 'block';
        
        // Reset all inputs when switching calculators
        resetInputs(type);
        
        // Scroll to calculator
        document.getElementById(type).scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Math Calculator
function mathCalc() {
    try {
        let exp = document.getElementById("mathInput").value;
        
        // Replace common math functions
        exp = exp.replace(/sqrt\(/g, 'Math.sqrt(');
        exp = exp.replace(/sin\(/g, 'Math.sin(');
        exp = exp.replace(/cos\(/g, 'Math.cos(');
        exp = exp.replace(/tan\(/g, 'Math.tan(');
        exp = exp.replace(/log\(/g, 'Math.log10(');
        exp = exp.replace(/ln\(/g, 'Math.log(');
        exp = exp.replace(/PI/g, 'Math.PI');
        exp = exp.replace(/pi/g, 'Math.PI');
        exp = exp.replace(/E/g, 'Math.E');
        
        // Evaluate expression
        let result = eval(exp);
        
        // Format result
        if (isNaN(result)) {
            throw new Error('Invalid calculation');
        }
        
        // Check if result is too large/small
        if (Math.abs(result) > 1e15 || (Math.abs(result) < 1e-15 && result !== 0)) {
            result = result.toExponential(6);
        } else {
            // Round to 10 decimal places to avoid floating point errors
            result = Math.round(result * 1e10) / 1e10;
        }
        
        document.getElementById("mathResult").innerText = result;
        
        // Add animation
        animateResult('mathResult');
        
    } catch (error) {
        document.getElementById("mathResult").innerText = "Invalid Expression";
        document.getElementById("mathResult").style.color = "#ef4444";
    }
}

// Finance Calculator - EMI Calculation
function emiCalc() {
    let P = parseFloat(document.getElementById("amount").value);
    let R = parseFloat(document.getElementById("rate").value) / 12 / 100;
    let N = parseFloat(document.getElementById("time").value) * 12;
    
    // Validate inputs
    if (isNaN(P) || isNaN(R) || isNaN(N) || P <= 0 || R <= 0 || N <= 0) {
        document.getElementById("emiResult").innerText = "Invalid Inputs";
        document.getElementById("emiResult").style.color = "#ef4444";
        return;
    }
    
    // EMI Formula: EMI = P × R × (1+R)^N / ((1+R)^N - 1)
    let EMI = (P * R * Math.pow(1 + R, N)) / (Math.pow(1 + R, N) - 1);
    
    // Format as currency
    let formattedEMI = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2
    }).format(EMI);
    
    document.getElementById("emiResult").innerText = formattedEMI;
    document.getElementById("emiResult").style.color = "#10b981";
    
    // Add animation
    animateResult('emiResult');
    
    // Show breakdown
    showEMIBreakdown(P, R, N, EMI);
}

function showEMIBreakdown(P, R, N, EMI) {
    let totalPayment = EMI * N;
    let totalInterest = totalPayment - P;
    
    console.log(`Loan Breakdown:
    Principal: $${P.toFixed(2)}
    Total Interest: $${totalInterest.toFixed(2)}
    Total Payment: $${totalPayment.toFixed(2)}
    Monthly EMI: $${EMI.toFixed(2)}`);
}

// Science Calculators
function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.style.display = 'none';
    });
    
    // Remove active class from all buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabName + '-tab').style.display = 'block';
    
    // Add active class to clicked button
    event.target.classList.add('active');
}

function speedCalc() {
    let distance = parseFloat(document.getElementById("distance").value);
    let time = parseFloat(document.getElementById("time2").value);
    
    if (isNaN(distance) || isNaN(time) || time === 0) {
        document.getElementById("speedResult").innerText = "Invalid Inputs";
        document.getElementById("speedResult").style.color = "#ef4444";
        return;
    }
    
    let speed = distance / time;
    document.getElementById("speedResult").innerText = speed.toFixed(2) + " m/s";
    document.getElementById("speedResult").style.color = "#3b82f6";
    
    animateResult('speedResult');
}

function forceCalc() {
    let mass = parseFloat(document.getElementById("mass").value);
    let acceleration = parseFloat(document.getElementById("acceleration").value);
    
    if (isNaN(mass) || isNaN(acceleration)) {
        document.getElementById("forceResult").innerText = "Invalid Inputs";
        return;
    }
    
    let force = mass * acceleration;
    document.getElementById("forceResult").innerText = force.toFixed(2) + " N";
    document.getElementById("forceResult").style.color = "#3b82f6";
    
    animateResult('forceResult');
}

function energyCalc() {
    let mass = parseFloat(document.getElementById("mass2").value);
    let velocity = parseFloat(document.getElementById("velocity").value);
    
    if (isNaN(mass) || isNaN(velocity)) {
        document.getElementById("energyResult").innerText = "Invalid Inputs";
        return;
    }
    
    let energy = 0.5 * mass * Math.pow(velocity, 2);
    document.getElementById("energyResult").innerText = energy.toFixed(2) + " J";
    document.getElementById("energyResult").style.color = "#3b82f6";
    
    animateResult('energyResult');
}

// Animation for results
function animateResult(elementId) {
    const element = document.getElementById(elementId);
    element.style.transform = 'scale(1.1)';
    element.style.transition = 'transform 0.3s ease';
    
    setTimeout(() => {
        element.style.transform = 'scale(1)';
    }, 300);
}

// Reset inputs when switching calculators
function resetInputs(type) {
    if (type === 'math') {
        document.getElementById("mathInput").value = '';
        document.getElementById("mathResult").innerText = '0';
        document.getElementById("mathResult").style.color = '#4f46e5';
    } else if (type === 'finance') {
        document.getElementById("amount").value = '';
        document.getElementById("rate").value = '';
        document.getElementById("time").value = '';
        document.getElementById("emiResult").innerText = '$0.00';
        document.getElementById("emiResult").style.color = '#4f46e5';
    } else if (type === 'science') {
        document.getElementById("distance").value = '';
        document.getElementById("time2").value = '';
        document.getElementById("speedResult").innerText = '0 m/s';
        document.getElementById("speedResult").style.color = '#4f46e5';
    }
}

// Keyboard support for math calculator
document.getElementById("mathInput").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        mathCalc();
    }
});

// Initialize with first tab active in science calculator
showTab('speed');